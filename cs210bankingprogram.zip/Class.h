#ifndef DATE_H
#define DATE_H

class invest
{
private:

public:
    invest(float initial, float monthly, float annual, int years);

    void moneymagic(float initial, float monthly, float annual, int years);

};

#endif

