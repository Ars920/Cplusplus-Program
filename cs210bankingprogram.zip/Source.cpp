//C210 SNHU
//Ashley Stiger

#include<iostream>
#include "Class.h"
using namespace std;

int main() {
	string userinput; //declares a string so when we begin typing the program doesn't break
	cout << "Airgead Banking Program\n"; //program title
	cout << "Enter Information Then View Reports\n"; //what we're doing here
	cout << "Please enter Start or Exit to continue.\n"; //prompts user to start typing keywords, prevents wasted time if program opened in error

	cin >> userinput; // gets the input

	if (userinput == "Start") { //runs the code below once the user types Start
		float t_init;
		float t_month;
		float t_ann;
		int t_years;
		cout << "What's your initial investment?";
		cin >> t_init;
		cout << "What's your monthly deposit?";
		cin >> t_month;
		cout << "What's your annual interest?";
		cin >> t_ann;
		cout << "How many years are you investing for?";
		cin >> t_years;

		invest temp(t_init, t_month, t_ann, t_years);

		cout << "Calculations complete.\n";
		main(); //loops program
	}

	else if(userinput == "Exit") { //if user types exit, turns the program off
		cout << "Thanks for using!\n";
		return 0;
	}

	else { //prompts user to make a valid selection and loops back to start if input isn't recognized
		cout << "Please enter a valid selection.\n";
		main();
	}
}