#include <iostream>
#include "Class.h"
using namespace std;

// invest constructor
invest::invest(float initial, float monthly, float annual, int years)
{
    moneymagic(initial, monthly, annual, years);
    int tick;
    int tock;
    int m_tock;
    float lastyear;
    float lasttime;
}

// moneymagic function
void invest::moneymagic(float initial, float monthly, float annual, int years)
{
    cout << "Balance and Interest Without Monthly Deposits\n";
    cout << "Year     Year End Balance     Year End Interest\n";
    int tick = 1; //integer that counts years, ends loop
    float lastyear = initial; //
    while (tick <= years) {
        cout << tick << "          " << (lastyear + ((lastyear / 100) * annual)) << "              " << ((lastyear / 100) * annual) << endl;
        tick = tick + 1;
        lastyear = (lastyear + ((lastyear / 100) * annual));
    }
    cout << "Balance and Interest With Monthly Deposits\n";
    cout << "Year     Year End Balance     Year End Interest\n";
    int tock = 1;
    int m_tock = 1;
    float month2month = initial;
    float year2year = initial;
    while (tock <= years) {
        while (m_tock < 12) {
            //internal loop runs 11 times for background calculations, no output for monthly data
            m_tock = m_tock + 1;
            month2month = ((((monthly + month2month) / 100) * (annual / 12)) + monthly + month2month);
        }
        //external loop runs for years, completes 12th month calculation, loops a value to determine interest via subtraction
        cout << tock << "          " << ((((monthly + month2month) / 100) * (annual / 12)) + monthly + month2month) << "           " << ((((((monthly + month2month) / 100) * (annual / 12)) + monthly + month2month)) - (year2year + (monthly*12))) << endl;
        tock = tock + 1;
        month2month = ((((monthly + month2month) / 100) * (annual / 12)) + monthly + month2month);
        year2year = month2month;
        m_tock = 1; //resets internal loop
    }
}